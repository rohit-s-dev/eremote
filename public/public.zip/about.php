<?php 
include("inc/header.php");
?>

<section class="abt_us">
    <div class="container">
        <div class="row">
            <div class="col-10 m-auto py-5 text-center">
            <h3 class="text-white t">About Us</h3>
            <p class="text-white ">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo recusandae ratione quasi beatae praesentium fugit voluptatibus voluptatum. Debitis maxime, facere in eum consectetur officia odit, atque laborum iste provident asperiores earum molestias reprehenderit possimus, optio architecto libero! Natus dolor inventore labore unde alias? Quae consequuntur rem at. Aliquid vero mollitia molestiae optio omnis aperiam. Illo, sint delectus velit incidunt, inventore eaque laboriosam pariatur asperiores ea ratione deserunt non, assumenda consequuntur!

            <br><br>
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo recusandae ratione quasi beatae praesentium fugit voluptatibus voluptatum. Debitis maxime, facere in eum consectetur officia odit, atque laborum iste provident asperiores earum molestias reprehenderit possimus, optio architecto libero! Natus dolor inventore labore unde alias? Quae consequuntur rem at. Aliquid vero mollitia molestiae optio omnis aperiam. Illo, sint delectus velit incidunt, inventore eaque laboriosam pariatur asperiores ea ratione deserunt non, assumenda consequuntur!
            </p>
            </div>
        </div>
    </div>
</section>


<?php 
include("inc/footer.php");
?>
